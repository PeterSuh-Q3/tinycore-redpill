#define MODE_MINIX2 1
#include "minix.c"
