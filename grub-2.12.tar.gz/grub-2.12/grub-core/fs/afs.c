#define MODE_AFS 1
#include "bfs.c"

