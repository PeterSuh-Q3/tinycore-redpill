#!/bin/sh
printf "\033]10;%s\007" "$1"
shift
if [ $# -gt 0 ]; then exec "$@"; else exec /bin/sh; fi
