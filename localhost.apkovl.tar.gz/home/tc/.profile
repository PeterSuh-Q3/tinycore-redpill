export ENV=~/.ashrc

TERMTYPE=`/usr/bin/tty`
[ "${TERMTYPE:5:3}" = "tty" ] && (
[ ! -f /etc/sysconfig/Xserver ] ||
[ -f /etc/sysconfig/text ] ||
[ -e /tmp/.X11-unix/X0 ] ||
{
  _n=0
  while [ $_n -lt 6 ]; do
    _t0=`date +%s`
    sx
    _t1=`date +%s`
    [ $((_t1 - _t0)) -ge 3 ] && break
    _n=$((_n+1))
    sleep 1
  done
}
)
