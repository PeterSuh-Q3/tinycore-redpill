source /usr/local/etc/bashrc
alias more=less
