#!/bin/sh
# put other system startup commands here
cd /usr/local/etc/ssh
cp sshd_config.orig ssh_config
sudo cp sshd_config.orig sshd_config
sudo cp ssh_config.orig ssh_config
sudo /usr/local/etc/init.d/openssh start
cat <<EOF
::::::::::: ::::::::  :::::::::  :::::::::   
    :+:    :+:    :+: :+:    :+: :+:    :+: 
    +:+    +:+        +:+    +:+ +:+    +:+ 
    +#+    +#+        +#++:++#:  +#++:++#+  
    +#+    +#+        +#+    +#+ +#+       
    #+#    #+#    #+# #+#    #+# #+#       
    ###     ########  ###    ### ###  TinyCore - RedPill 
EOF


sudo /home/tc/ttyd login -f tc 2>/dev/null &
[ $(/bin/uname -r | /bin/grep 4.14.10 | /usr/bin/wc -l) -eq 1 ] && {( sleep 5; sudo openvt -c 2 -s bash -c "/home/tc/mountvol.sh; exec sudo login -f tc") & }
